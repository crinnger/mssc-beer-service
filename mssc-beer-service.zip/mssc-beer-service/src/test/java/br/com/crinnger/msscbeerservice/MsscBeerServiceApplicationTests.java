package br.com.crinnger.msscbeerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsscBeerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
